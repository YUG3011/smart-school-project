export default function AIReportsPage() {
  return (
    <div className="page-container">
      <h1>AI Reports</h1>
      <p>AI-generated reports will show here.</p>
    </div>
  );
}
