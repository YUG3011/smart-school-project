// src/pages/Timetable/EditTimetable.jsx

import { useEffect, useState } from "react";
import api from "../../services/api";
import { useNavigate, useParams } from "react-router-dom";

export default function EditTimetable() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    class_name: "",
    subject: "",
    teacher_name: "",
    day: "",
    time: "",
  });

  const loadEntry = async () => {
    const data = await api.getTimetable();
    const entry = data.find((t) => t.id === Number(id));
    if (entry) setForm(entry);
  };

  useEffect(() => {
    loadEntry();
  }, []);

  const updateEntry = async (e) => {
    e.preventDefault();

    const res = await api.updateTimetable(id, form);
    if (res.message) {
      alert("Timetable updated successfully");
      navigate("/admin/timetable");
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Edit Timetable Entry</h1>

      <form
        onSubmit={updateEntry}
        className="bg-white p-5 rounded shadow grid grid-cols-2 gap-4"
      >
        <input
          type="text"
          placeholder="Class"
          value={form.class_name}
          onChange={(e) => setForm({ ...form, class_name: e.target.value })}
          className="border p-2 rounded"
          required
        />

        <input
          type="text"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
          className="border p-2 rounded"
          required
        />

        <input
          type="text"
          placeholder="Teacher Name"
          value={form.teacher_name}
          onChange={(e) =>
            setForm({ ...form, teacher_name: e.target.value })
          }
          className="border p-2 rounded"
          required
        />

        <select
          value={form.day}
          onChange={(e) => setForm({ ...form, day: e.target.value })}
          className="border p-2 rounded"
          required
        >
          <option>Select Day</option>
          <option>Monday</option>
          <option>Tuesday</option>
          <option>Wednesday</option>
          <option>Thursday</option>
          <option>Friday</option>
          <option>Saturday</option>
        </select>

        <input
          type="time"
          value={form.time}
          onChange={(e) => setForm({ ...form, time: e.target.value })}
          className="border p-2 rounded"
          required
        />

        <button className="col-span-2 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded">
          Update Timetable
        </button>
      </form>
    </div>
  );
}
