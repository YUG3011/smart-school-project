import { useState } from "react";
import api from "../../services/api";
import { useNavigate } from "react-router-dom";

export default function AddTimetable() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    class_name: "",
    day: "",
    subject: "",
    start_time: "",
    end_time: "",
    teacher_name: "",
  });

  const updateField = (key, value) => {
    setForm({ ...form, [key]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.addTimetable(form);
      alert("Timetable added");
      navigate("/admin/timetable");
    } catch (error) {
      console.error(error);
      alert("Failed to add timetable");
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Add Timetable Entry</h1>

      <form className="bg-white p-6 shadow rounded grid grid-cols-2 gap-4" onSubmit={handleSubmit}>
        <input
          type="text"
          className="border p-2 rounded"
          placeholder="Class (10A)"
          value={form.class_name}
          onChange={(e) => updateField("class_name", e.target.value)}
          required
        />

        <select
          className="border p-2 rounded"
          value={form.day}
          onChange={(e) => updateField("day", e.target.value)}
          required
        >
          <option value="">Select Day</option>
          {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map(
            (d) => (
              <option key={d} value={d}>
                {d}
              </option>
            )
          )}
        </select>

        <input
          type="text"
          className="border p-2 rounded"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => updateField("subject", e.target.value)}
          required
        />

        <input
          type="time"
          className="border p-2 rounded"
          value={form.start_time}
          onChange={(e) => updateField("start_time", e.target.value)}
          required
        />

        <input
          type="time"
          className="border p-2 rounded"
          value={form.end_time}
          onChange={(e) => updateField("end_time", e.target.value)}
          required
        />

        <input
          type="text"
          className="border p-2 rounded"
          placeholder="Teacher Name"
          value={form.teacher_name}
          onChange={(e) => updateField("teacher_name", e.target.value)}
          required
        />

        <button className="col-span-2 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded">
          Add Timetable
        </button>
      </form>
    </div>
  );
}
