export default function ParentPerformance() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Child Performance</h1>
      <p>Performance reports will be added here...</p>
    </div>
  );
}
