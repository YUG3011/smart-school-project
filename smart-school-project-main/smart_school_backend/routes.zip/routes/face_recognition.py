# smart_school_backend/routes/face_recognition.py

import base64
import numpy as np
import face_recognition
from flask import Blueprint, request, jsonify
from utils.db import get_db
from models.face_recognition import (
    save_face_embedding,
    load_all_embeddings
)

bp = Blueprint("face_recognition", __name__)

# ---------------------------------------------------------
# Utility: Decode image
# ---------------------------------------------------------
def decode_base64_image(image_base64):
    try:
        header, encoded = image_base64.split(",", 1)
    except ValueError:
        encoded = image_base64

    img_bytes = base64.b64decode(encoded)
    nparr = np.frombuffer(img_bytes, np.uint8)

    return face_recognition.load_image_file(nparr)


# ---------------------------------------------------------
# ENROLL FACE (student & teacher)
# ---------------------------------------------------------
@bp.route("/enroll", methods=["POST"])
def enroll_face_student():
    data = request.json
    name = data.get("name")
    email = data.get("email")
    class_name = data.get("class_name")
    section = data.get("section")
    image_base64 = data.get("image_base64")

    if not all([name, email, class_name, section, image_base64]):
        return jsonify({"error": "Missing required fields"}), 400

    db = get_db()
    cursor = db.cursor()

    # Insert student first
    cursor.execute(
        "INSERT INTO students (name, email, class_name, section) VALUES (?, ?, ?, ?)",
        (name, email, class_name, section)
    )
    db.commit()

    student_id = cursor.lastrowid

    # Decode image
    img = face_recognition.load_image_file(
        np.frombuffer(base64.b64decode(image_base64.split(",")[1]), np.uint8)
    )

    face_locations = face_recognition.face_locations(img)
    if not face_locations:
        return jsonify({"error": "No face detected!"}), 400

    embedding = face_recognition.face_encodings(img, face_locations)[0]

    # Save embedding
    save_face_embedding("student", student_id, name, embedding.astype(np.float32))

    return jsonify({"message": "Student enrolled successfully", "student_id": student_id}), 200


# ---------------------------------------------------------
# ENROLL TEACHER
# ---------------------------------------------------------
@bp.route("/enroll-teacher", methods=["POST"])
def enroll_face_teacher():
    data = request.json
    name = data.get("name")
    email = data.get("email")
    image_base64 = data.get("image_base64")

    if not all([name, email, image_base64]):
        return jsonify({"error": "Missing required fields"}), 400

    db = get_db()
    cursor = db.cursor()

    cursor.execute(
        "INSERT INTO teachers (name, email, subject) VALUES (?, ?, ?)",
        (name, email, "Not Assigned")
    )
    db.commit()

    teacher_id = cursor.lastrowid

    img = face_recognition.load_image_file(
        np.frombuffer(base64.b64decode(image_base64.split(",")[1]), np.uint8)
    )

    face_locations = face_recognition.face_locations(img)
    if not face_locations:
        return jsonify({"error": "No face detected!"}), 400

    embedding = face_recognition.face_encodings(img, face_locations)[0]

    save_face_embedding("teacher", teacher_id, name, embedding.astype(np.float32))

    return jsonify({"message": "Teacher enrolled successfully", "teacher_id": teacher_id}), 200


# ---------------------------------------------------------
# UNIVERSAL FACE RECOGNITION
# ---------------------------------------------------------
@bp.route("/recognize", methods=["POST"])
def recognize_face_api():
    data = request.json
    image_base64 = data.get("image_base64")

    if not image_base64:
        return jsonify({"error": "Image required"}), 400

    img = face_recognition.load_image_file(
        np.frombuffer(base64.b64decode(image_base64.split(",")[1]), np.uint8)
    )

    face_locations = face_recognition.face_locations(img)
    if not face_locations:
        return jsonify({"matched": False, "message": "No face detected"}), 200

    face_enc = face_recognition.face_encodings(img, face_locations)[0]

    stored_embeddings, metadata = load_all_embeddings()

    if len(stored_embeddings) == 0:
        return jsonify({"matched": False, "message": "No enrolled faces"}), 200

    # Compare distances
    distances = np.linalg.norm(stored_embeddings - face_enc, axis=1)
    best_index = np.argmin(distances)
    best_distance = distances[best_index]

    if best_distance < 0.45:
        return jsonify({
            "matched": True,
            "person": metadata[best_index],
            "distance": float(best_distance)
        }), 200
    else:
        return jsonify({
            "matched": False,
            "message": "Unknown face",
            "distance": float(best_distance)
        }), 200
