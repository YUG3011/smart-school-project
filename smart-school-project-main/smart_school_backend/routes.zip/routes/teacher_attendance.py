# smart_school_backend/routes/teacher_attendance.py

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from utils.db import get_db
from datetime import datetime

bp = Blueprint("teacher_attendance_bp", __name__)

# Create table if missing
def create_teacher_attendance_table():
    db = get_db()
    cur = db.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS teacher_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    db.commit()


@bp.route("/mark", methods=["POST"])
@jwt_required()
def mark_teacher_attendance():
    identity = get_jwt_identity()

    if identity["role"] != "teacher":
        return jsonify({"error": "Only teachers can mark attendance"}), 403

    teacher_id = identity["id"]
    today = datetime.now().strftime("%Y-%m-%d")

    db = get_db()
    cur = db.cursor()

    # Check if attendance already exists
    cur.execute(
        "SELECT id FROM teacher_attendance WHERE teacher_id=? AND date=?",
        (teacher_id, today),
    )
    exists = cur.fetchone()

    if exists:
        return jsonify({"message": "Attendance already marked for today"}), 400

    cur.execute("""
        INSERT INTO teacher_attendance (teacher_id, date, time, status)
        VALUES (?, ?, ?, ?)
    """, (
        teacher_id,
        today,
        datetime.now().strftime("%H:%M:%S"),
        "Present"
    ))

    db.commit()

    return jsonify({"message": "Attendance marked successfully"}), 200


@bp.route("/records", methods=["GET"])
@jwt_required()
def get_teacher_attendance_records():
    identity = get_jwt_identity()
    teacher_id = identity["id"]

    db = get_db()
    cur = db.cursor()

    cur.execute("""
        SELECT date, time, status
        FROM teacher_attendance
        WHERE teacher_id=?
        ORDER BY date DESC
    """, (teacher_id,))

    rows = cur.fetchall()

    records = [dict(row) for row in rows]

    return jsonify(records), 200
