# smart_school_backend/models/face_recognition.py

import numpy as np
from utils.db import get_db

# ---------------------------------------------------------
# Create table for storing face embeddings
# ---------------------------------------------------------
def create_face_embeddings_table():
    db = get_db()
    cursor = db.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS face_embeddings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person_type TEXT NOT NULL,
            person_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            embedding BLOB NOT NULL
        )
        """
    )
    db.commit()


# ---------------------------------------------------------
# Save embeddings to DB
# ---------------------------------------------------------
def save_face_embedding(person_type, person_id, name, embedding_array):
    db = get_db()
    cursor = db.cursor()

    embedding_bytes = embedding_array.tobytes()

    cursor.execute(
        """
        INSERT INTO face_embeddings (person_type, person_id, name, embedding)
        VALUES (?, ?, ?, ?)
        """,
        (person_type, person_id, name, embedding_bytes),
    )

    db.commit()
    return True


# ---------------------------------------------------------
# Fetch all embeddings
# ---------------------------------------------------------
def load_all_embeddings():
    db = get_db()
    cursor = db.cursor()

    cursor.execute(
        """
        SELECT id, person_type, person_id, name, embedding FROM face_embeddings
        """
    )

    rows = cursor.fetchall()

    embeddings = []
    metadata = []

    for row in rows:
        embedding = np.frombuffer(row[4], dtype=np.float32)

        embeddings.append(embedding)
        metadata.append(
            {
                "db_id": row[0],
                "person_type": row[1],
                "person_id": row[2],
                "name": row[3],
            }
        )

    return np.array(embeddings), metadata
